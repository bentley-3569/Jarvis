plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.jarvis"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.jarvis"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    // The Vosk speech model is big and already compressed; keep it as-is in the APK.
    androidResources { noCompress += listOf("mdl", "fst", "conf", "int", "txt", "mat", "stats", "dubm", "ie") }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    // Vosk offline speech recognition (free, no account). Check https://alphacephei.com/vosk/ for newer versions.
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    implementation("com.alphacephei:vosk-android:0.3.47@aar")
}
