package com.example.jarvis

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.location.LocationManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.SmsManager
import android.view.KeyEvent
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.random.Random

/**
 * Turns a spoken sentence into an action. Add new features by adding a case in [route].
 * (Later: send anything unmatched to an LLM API for open-ended answers.)
 */
class CommandHandler(
    private val context: Context,
    private val say: (String) -> Unit
) {

    fun handle(raw: String) {
        val text = raw.lowercase(Locale.getDefault()).trim().trimEnd('.', '!', '?')
        try {
            route(text)
        } catch (e: Exception) {
            say("I'm afraid something went wrong, sir.")
        }
    }

    private fun route(text: String) {
        when {
            // calling, texting, contacts, apps
            text.startsWith("call ") || text.startsWith("phone ") -> call(text.substringAfter(" ").trim())
            text.startsWith("text ") || text.startsWith("message ") -> sendText(text.substringAfter(" ").trim())

            // popup menu
            text in MENU_WORDS -> {
                launch(Intent(context, MenuActivity::class.java))
                say("Certainly, sir. Here is what I can do.")
            }

            // voice lock
            "learn my voice" in text || "train my voice" in text ->
                context.startService(Intent(context, JarvisService::class.java).setAction(JarvisService.ACTION_ENROLL))
            "forget my voice" in text -> forgetVoice()
            "stricter" in text -> adjustVoice(-0.05f)
            "less strict" in text || "looser" in text -> adjustVoice(0.05f)

            // settings screens (Android doesn't let apps flip these switches, so we open the screen)
            "bluetooth" in text -> openSettings(Settings.ACTION_BLUETOOTH_SETTINGS, "Bluetooth settings")
            "wifi" in text || "wi-fi" in text || "wi fi" in text -> openSettings(Settings.ACTION_WIFI_SETTINGS, "Wi-Fi settings")
            "airplane" in text -> openSettings(Settings.ACTION_AIRPLANE_MODE_SETTINGS, "airplane mode settings")
            "brightness" in text || "display settings" in text -> openSettings(Settings.ACTION_DISPLAY_SETTINGS, "display settings")
            "do not disturb" in text || "sound settings" in text -> openSettings(Settings.ACTION_SOUND_SETTINGS, "sound settings")
            "battery saver" in text -> openSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS, "battery saver settings")
            text in setOf("open settings", "settings") -> openSettings(Settings.ACTION_SETTINGS, "settings")
            text in setOf("open contacts", "open my contacts", "show contacts") -> {
                launch(Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI))
                say("Opening contacts")
            }
            text.startsWith("open ") -> openApp(text.removePrefix("open ").trim())

            // navigation and search
            NAVIGATE.containsMatchIn(text) -> navigate(NAVIGATE.find(text)!!.groupValues[1])
            text.startsWith("search for ") -> webSearch(text.removePrefix("search for "))
            text.startsWith("search ") -> webSearch(text.removePrefix("search "))
            text.startsWith("google ") -> webSearch(text.removePrefix("google "))
            text.startsWith("look up ") -> webSearch(text.removePrefix("look up "))

            // timers and alarms
            "timer" in text -> setTimer(text)
            "alarm" in text || text.startsWith("wake me") -> setAlarm(text)

            // speak a sentence out loud (put the call on speakerphone and the other person hears it)
            SAY.containsMatchIn(text) -> say(SAY.find(text)!!.groupValues[1])

            // "play lofi on spotify" / "play despacito on youtube"
            text.startsWith("play ") && " on " in text -> playOn(text.removePrefix("play "))

            // phone controls
            "flashlight" in text || "torch" in text -> flashlight(on = "off" !in text)
            text in setOf("pause", "pause music", "stop music", "stop the music") -> mediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE)
            text in setOf("play", "play music", "resume", "resume music") -> mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY)
            text.startsWith("next") || "skip" in text -> mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT)
            text.startsWith("previous") || text.startsWith("go back") -> mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            VOLUME_SET.containsMatchIn(text) -> setVolume(VOLUME_SET.find(text)!!.groupValues[1].toInt())
            text == "mute" || text == "unmute" -> mute(text == "mute")
            "volume up" in text || "louder" in text || "turn it up" in text -> volume(raise = true)
            "volume down" in text || "quieter" in text || "turn it down" in text -> volume(raise = false)

            // camera and home
            "take a photo" in text || "take a picture" in text || "take a selfie" in text -> {
                launch(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
                say("Opening the camera")
            }
            text in setOf("go home", "home screen") ->
                launch(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME))

            // quick info
            "battery" in text -> battery()
            "what time" in text -> say("It's " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()) + ", sir.")
            "what day" in text || "the date" in text || "today's date" in text ->
                say("Today is " + SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(Date()))
            "weather" in text -> weather(WEATHER_CITY.find(text)?.groupValues?.get(1))

            // notes
            text.startsWith("remind me to ") -> saveNote(text.removePrefix("remind me to "))
            text.startsWith("take a note ") -> saveNote(text.removePrefix("take a note ").removePrefix("that "))
            text.startsWith("note ") -> saveNote(text.removePrefix("note ").removePrefix("that "))
            "my notes" in text && ("clear" in text || "delete" in text) -> clearNotes()
            "my notes" in text || text == "read notes" -> readNotes()

            // fun
            "joke" in text -> say(JOKES.random())
            "a fact" in text || "fun fact" in text -> say(FACTS.random())
            NUMBER_BETWEEN.containsMatchIn(text) -> randomNumber(NUMBER_BETWEEN.find(text)!!)
            "flip a coin" in text || "coin flip" in text -> say(if (Random.nextBoolean()) "Heads" else "Tails")
            "roll a die" in text || "roll a dice" in text || "roll dice" in text ->
                say("You rolled a ${Random.nextInt(1, 7)}")

            else -> if (!tryMath(text)) say("I'm afraid I don't know how to do that yet, sir.")
        }
    }

    // ---- calling and texting ---------------------------------------------

    private fun call(name: String) {
        val match = findContact(name)
        if (match == null) {
            say("I'm afraid I couldn't find $name in your contacts, sir.")
            return
        }
        try {
            val telecom = context.getSystemService(TelecomManager::class.java)
            telecom.placeCall(Uri.fromParts("tel", match.number, null), null)
            say("Right away, sir. Calling ${match.name}.")
        } catch (e: SecurityException) {
            say("I need phone permission to place calls.")
        }
    }

    /** "text Mom I'm on my way" or "text Mom saying I'm on my way". Sends immediately, no confirmation. */
    private fun sendText(rest: String) {
        val m = Regex("^(.+?) (?:saying|that says|that|says) (.+)$").find(rest)
        val (name, body) = if (m != null) {
            m.groupValues[1] to m.groupValues[2]
        } else {
            rest.substringBefore(" ") to rest.substringAfter(" ", "")
        }
        if (body.isBlank()) {
            say("What should the text say?")
            return
        }
        val match = findContact(name)
        if (match == null) {
            say("I'm afraid I couldn't find $name in your contacts, sir.")
            return
        }
        if (!granted(Manifest.permission.SEND_SMS)) {
            say("I need permission to send texts.")
            return
        }
        val sms = context.getSystemService(SmsManager::class.java)
        val message = body.replaceFirstChar { it.uppercase() }
        sms.sendMultipartTextMessage(match.number, null, sms.divideMessage(message), null, null)
        say("Texted ${match.name}: $message")
    }

    private data class Match(val name: String, val number: String)

    /** Best match wins: exact name, then starts-with, then contains. */
    private fun findContact(query: String): Match? {
        val candidates = mutableListOf<Match>()
        context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$query%"),
            null
        )?.use { c ->
            while (c.moveToNext()) candidates += Match(c.getString(0), c.getString(1))
        }
        return candidates.minByOrNull {
            val n = it.name.lowercase(Locale.getDefault())
            when {
                n == query -> 0
                n.startsWith(query) -> 1
                else -> 2
            }
        }
    }

    // ---- opening apps, search, navigation --------------------------------

    private fun openApp(label: String) {
        val pm = context.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val app = pm.queryIntentActivities(launcher, PackageManager.MATCH_ALL)
            .firstOrNull { it.loadLabel(pm).toString().lowercase(Locale.getDefault()).contains(label) }

        if (app == null) {
            say("I couldn't find an app called $label.")
            return
        }
        pm.getLaunchIntentForPackage(app.activityInfo.packageName)?.let {
            launch(it)
            say("Opening ${app.loadLabel(pm)}")
        }
    }

    private fun webSearch(query: String) {
        launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${enc(query)}")))
        say("Searching for $query")
    }

    private fun navigate(place: String) {
        launch(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=${enc(place)}")))
        say("Navigating to $place")
    }

    // ---- timers and alarms -----------------------------------------------

    private fun setTimer(text: String) {
        val seconds = TIMER_PART.findAll(text).sumOf { m ->
            val n = m.groupValues[1].toInt()
            when {
                m.groupValues[2].startsWith("h") -> n * 3600
                m.groupValues[2].startsWith("m") -> n * 60
                else -> n
            }
        }
        if (seconds <= 0) {
            say("How long should the timer be?")
            return
        }
        launch(
            Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "Jarvis timer")
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        val h = seconds / 3600
        val m = (seconds % 3600) / 60
        val s = seconds % 60
        val spoken = listOfNotNull(
            if (h > 0) "$h hour${if (h > 1) "s" else ""}" else null,
            if (m > 0) "$m minute${if (m > 1) "s" else ""}" else null,
            if (s > 0) "$s second${if (s > 1) "s" else ""}" else null
        ).joinToString(" ")
        say("As you wish, sir. Timer set for $spoken.")
    }

    private fun setAlarm(text: String) {
        val m = TIME.find(text)
        if (m == null) {
            say("What time should I set the alarm for?")
            return
        }
        var hour = m.groupValues[1].toInt()
        val minute = m.groupValues[2].ifEmpty { "0" }.toInt()
        val meridiem = m.groupValues[3]
        when {
            meridiem.startsWith("p") && hour < 12 -> hour += 12
            meridiem.startsWith("a") && hour == 12 -> hour = 0
            meridiem.isEmpty() && hour in 1..12 -> {
                // No am/pm said: pick whichever comes next.
                val now = Calendar.getInstance()
                val nowMin = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
                val am = (hour % 12) * 60 + minute
                hour = when {
                    am > nowMin -> hour % 12
                    am + 720 > nowMin -> hour % 12 + 12
                    else -> hour % 12
                }
            }
        }
        if (hour > 23 || minute > 59) {
            say("That doesn't look like a valid time.")
            return
        }
        launch(
            Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, hour)
                .putExtra(AlarmClock.EXTRA_MINUTES, minute)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "Jarvis alarm")
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute) }
        say("Alarm set for " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(cal.time))
    }

    // ---- phone controls --------------------------------------------------

    private fun flashlight(on: Boolean) {
        val cm = context.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
        if (id == null) {
            say("This phone has no flashlight.")
            return
        }
        cm.setTorchMode(id, on)
        say(if (on) "Flashlight on" else "Flashlight off")
    }

    private fun mediaKey(code: Int) {
        val audio = context.getSystemService(AudioManager::class.java)
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun volume(raise: Boolean) {
        val audio = context.getSystemService(AudioManager::class.java)
        repeat(2) {
            audio.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                if (raise) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                AudioManager.FLAG_SHOW_UI
            )
        }
    }

    private fun battery() {
        val bm = context.getSystemService(BatteryManager::class.java)
        say("Battery is at ${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)} percent")
    }

    // ---- weather (Open-Meteo, free, no key) -------------------------------

    private fun weather(city: String?) {
        thread {
            try {
                val lat: Double
                val lon: Double
                val place: String
                if (!city.isNullOrBlank()) {
                    val geo = JSONObject(httpGet("https://geocoding-api.open-meteo.com/v1/search?name=${enc(city)}&count=1"))
                    val hit = geo.optJSONArray("results")?.getJSONObject(0)
                    if (hit == null) {
                        say("I couldn't find a place called $city.")
                        return@thread
                    }
                    lat = hit.getDouble("latitude")
                    lon = hit.getDouble("longitude")
                    place = hit.getString("name")
                } else {
                    val loc = lastKnownLocation()
                    if (loc == null) {
                        say("I can't tell where you are. Try saying weather in, then a city.")
                        return@thread
                    }
                    lat = loc.first
                    lon = loc.second
                    place = "your area"
                }
                val w = JSONObject(
                    httpGet(
                        "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                            "&current=temperature_2m,weather_code&temperature_unit=fahrenheit"
                    )
                ).getJSONObject("current")
                val temp = w.getDouble("temperature_2m").toInt()
                say("In $place it's $temp degrees and ${describeWeather(w.getInt("weather_code"))}")
            } catch (e: Exception) {
                say("I couldn't get the weather. Check your internet connection.")
            }
        }
    }

    private fun lastKnownLocation(): Pair<Double, Double>? {
        if (!granted(Manifest.permission.ACCESS_COARSE_LOCATION)) return null
        val lm = context.getSystemService(LocationManager::class.java)
        for (provider in lm.getProviders(true)) {
            @Suppress("MissingPermission")
            val loc = lm.getLastKnownLocation(provider)
            if (loc != null) return loc.latitude to loc.longitude
        }
        return null
    }

    private fun describeWeather(code: Int) = when (code) {
        0 -> "clear"
        1, 2, 3 -> "partly cloudy"
        45, 48 -> "foggy"
        in 51..57 -> "drizzling"
        in 61..67 -> "raining"
        in 71..77 -> "snowing"
        in 80..82 -> "showery"
        85, 86 -> "snow showers"
        in 95..99 -> "stormy"
        else -> "mixed conditions"
    }

    private fun httpGet(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 8000
        conn.readTimeout = 8000
        return try {
            conn.inputStream.bufferedReader().readText()
        } finally {
            conn.disconnect()
        }
    }

    // ---- settings, media apps, volume, random ------------------------------

    private fun openSettings(action: String, label: String) {
        launch(Intent(action))
        say("Opening $label. Android needs you to tap the switch yourself.")
    }

    private fun playOn(rest: String) {
        val song = rest.substringBeforeLast(" on ").trim()
        val app = rest.substringAfterLast(" on ").trim()
        when {
            "youtube" in app ->
                launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=${enc(song)}")))
            "spotify" in app ->
                launch(Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:${Uri.encode(song)}")))
            else -> {
                say("I can play on YouTube or Spotify.")
                return
            }
        }
        say("Searching $app for $song")
    }

    private fun setVolume(percent: Int) {
        val audio = context.getSystemService(AudioManager::class.java)
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        audio.setStreamVolume(
            AudioManager.STREAM_MUSIC,
            max * percent.coerceIn(0, 100) / 100,
            AudioManager.FLAG_SHOW_UI
        )
    }

    private fun mute(on: Boolean) {
        val audio = context.getSystemService(AudioManager::class.java)
        audio.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            if (on) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE,
            AudioManager.FLAG_SHOW_UI
        )
    }

    private fun randomNumber(m: MatchResult) {
        val a = m.groupValues[1].toInt()
        val b = m.groupValues[2].toInt()
        if (a > b) say("The first number needs to be the smaller one.") else say("${Random.nextInt(a, b + 1)}")
    }

    // ---- voice lock settings -------------------------------------------------

    private val voicePrefs get() = context.getSharedPreferences("jarvis_voice", Context.MODE_PRIVATE)

    private fun forgetVoice() {
        voicePrefs.edit().remove("profile").apply()
        say("Very well, sir. I shall answer to any voice again.")
    }

    /** Lower limit = stricter matching. */
    private fun adjustVoice(delta: Float) {
        val limit = (voicePrefs.getFloat("threshold", 0.6f) + delta).coerceIn(0.3f, 0.9f)
        voicePrefs.edit().putFloat("threshold", limit).apply()
        say(if (delta < 0) "Voice matching is now stricter, sir." else "Voice matching is now more relaxed, sir.")
    }

    // ---- notes (saved on the phone; no alerts) ----------------------------

    private val prefs get() = context.getSharedPreferences("jarvis_notes", Context.MODE_PRIVATE)

    private fun notes(): List<String> =
        prefs.getString("notes", "").orEmpty().split("\n").filter { it.isNotBlank() }

    private fun saveNote(note: String) {
        if (note.isBlank()) {
            say("What should I write down?")
            return
        }
        prefs.edit().putString("notes", (notes() + note.trim()).joinToString("\n")).apply()
        say("Saved. Ask me to read your notes anytime.")
    }

    private fun readNotes() {
        val list = notes()
        if (list.isEmpty()) say("You have no notes.")
        else say("You have ${list.size} note${if (list.size > 1) "s" else ""}. " + list.joinToString(". "))
    }

    private fun clearNotes() {
        prefs.edit().remove("notes").apply()
        say("Notes cleared.")
    }

    // ---- math ------------------------------------------------------------

    private fun tryMath(text: String): Boolean {
        PERCENT.find(text)?.let {
            val (p, n) = it.destructured
            say("${fmt(p.toDouble() / 100.0 * n.toDouble())}")
            return true
        }
        val m = BINARY.find(text) ?: return false
        val a = m.groupValues[1].toDouble()
        val b = m.groupValues[3].toDouble()
        val result = when (m.groupValues[2]) {
            "plus", "+" -> a + b
            "minus", "-" -> a - b
            "times", "multiplied by", "x", "*" -> a * b
            else -> {
                if (b == 0.0) {
                    say("I can't divide by zero.")
                    return true
                }
                a / b
            }
        }
        say(fmt(result))
        return true
    }

    private fun fmt(d: Double) =
        if (d == d.toLong().toDouble()) d.toLong().toString() else String.format(Locale.US, "%.2f", d)

    // ---- helpers ---------------------------------------------------------

    private fun granted(permission: String) =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun launch(intent: Intent) {
        context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    companion object {
        private val MENU_WORDS = setOf("menu", "show menu", "show the menu", "open menu", "help", "what can you do")
        private val SAY = Regex("^(?:say|tell them|tell her|tell him)(?: on the call)?:? (.+)")
        private val VOLUME_SET = Regex("volume (?:to )?(\\d{1,3})")
        private val NUMBER_BETWEEN = Regex("number between (\\d+) and (\\d+)")
        private val FACTS = listOf(
            "Honey never spoils. Edible honey has been found in ancient Egyptian tombs.",
            "Octopuses have three hearts.",
            "A day on Venus is longer than a year on Venus.",
            "Bananas are berries, but strawberries are not.",
            "Sharks existed before trees did."
        )
        private val NAVIGATE = Regex("^(?:navigate to|navigate|directions to|take me to) (.+)")
        private val WEATHER_CITY = Regex("weather (?:in|for|at) (.+)")
        private val TIMER_PART = Regex("(\\d+)\\s*(seconds?|secs?|minutes?|mins?|hours?|hrs?)")
        private val TIME = Regex("(\\d{1,2})(?::(\\d{2}))?\\s*(a\\.?m\\.?|p\\.?m\\.?)?")
        private val PERCENT = Regex("(-?\\d+(?:\\.\\d+)?)\\s*(?:%|percent) of (-?\\d+(?:\\.\\d+)?)")
        private val BINARY = Regex(
            "(-?\\d+(?:\\.\\d+)?)\\s*(plus|\\+|minus|-|times|multiplied by|x|\\*|divided by|over|/)\\s*(-?\\d+(?:\\.\\d+)?)"
        )
        private val JOKES = listOf(
            "Why don't scientists trust atoms? Because they make up everything.",
            "I told my phone I needed space, so it opened the calendar.",
            "Why did the scarecrow win an award? He was outstanding in his field.",
            "I'd tell you a UDP joke, but you might not get it.",
            "What do you call a fake noodle? An impasta.",
            "Why did the developer go broke? He used up all his cache."
        )
    }
}
