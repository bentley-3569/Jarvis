package com.example.jarvis

import android.app.Activity
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Popup (dialog-style) list of everything Jarvis can do. Opened by "Jarvis, menu" or the app's button. */
class MenuActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Jarvis commands"

        val body = TextView(this).apply {
            text = MENU
            textSize = 15f
            setPadding(40, 24, 40, 24)
        }
        val close = Button(this).apply {
            text = "Close"
            setOnClickListener { finish() }
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(
                ScrollView(this@MenuActivity).apply { addView(body) },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            )
            addView(close)
        })
    }

    companion object {
        val MENU = """
            Say "Jarvis", wait for the beep, then:

            CALLS AND TEXTS
            - call Mom
            - text Mom I'm on my way
            - say hello, how are you  (speaks out loud; use speakerphone on a call)

            APPS AND SETTINGS
            - open contacts / open Spotify
            - Bluetooth settings / Wi-Fi settings
            - airplane mode / brightness / sound settings
            - battery saver / open settings / go home
            - take a photo

            TIME
            - set a timer for 10 minutes
            - set an alarm for 7:30 am
            - what time is it / what's the date

            MUSIC AND VOLUME
            - play / pause / next song / previous
            - play despacito on YouTube
            - play lofi on Spotify
            - volume up / volume down
            - set volume to 50
            - mute / unmute
            - flashlight on / off

            INFO
            - battery
            - weather / weather in Denver
            - search for cheap flights
            - navigate to Walmart

            MATH AND FUN
            - what's 15% of 80
            - 12 times 7
            - tell me a joke / tell me a fun fact
            - flip a coin / roll a die
            - pick a number between 1 and 10

            NOTES
            - remind me to buy milk
            - read my notes / clear my notes

            VOICE LOCK
            - learn my voice (say "Jarvis" 5 times)
            - forget my voice
            - be stricter / be less strict

            HELP
            - menu / help / what can you do
        """.trimIndent()
    }
}
