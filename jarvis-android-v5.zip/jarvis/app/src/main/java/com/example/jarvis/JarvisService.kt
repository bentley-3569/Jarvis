package com.example.jarvis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import java.util.Locale
import android.content.Context
import org.json.JSONObject
import org.vosk.SpeakerModel
import kotlin.math.sqrt
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import java.io.File
import kotlin.concurrent.thread

/**
 * Foreground service: listens for "Jarvis" offline with Vosk (restricted to that one word),
 * beeps, records one command with Android's SpeechRecognizer, runs it, then resumes listening.
 */
class JarvisService : Service() {

    private val main = Handler(Looper.getMainLooper())
    private var model: Model? = null
    private var wakeService: SpeechService? = null
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var triggered = false
    private var spkModel: SpeakerModel? = null
    private var enrolling = false
    private var pendingEnroll = false
    private val enrollSamples = mutableListOf<DoubleArray>()
    private lateinit var commands: CommandHandler

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                setUpJarvisVoice()
                ttsReady = true
            }
        }
        commands = CommandHandler(this) { say(it) }
        loadModelThenListen()
    }

    // ---- wake word (Vosk) ------------------------------------------------

    /** Copies assets/model to internal storage once, loads it off the main thread, then starts listening. */
    private fun loadModelThenListen() {
        thread {
            try {
                val dir = File(filesDir, "model")
                if (!File(dir, "am/final.mdl").exists()) copyAssetDir("model", dir)
                model = Model(dir.absolutePath)
                loadSpeakerModel()
                main.post {
                    startWakeWord()
                    // Don't say his own name here: the wake-word listener would hear it and trigger itself.
                    if (!enrolling) say("Online and at your service, sir.")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Model load failed", e)
                main.post {
                    say("Speech model missing. See the readme.")
                    stopSelf()
                }
            }
        }
    }

    private fun copyAssetDir(assetPath: String, target: File) {
        val children = assets.list(assetPath) ?: emptyArray()
        if (children.isEmpty()) {
            target.parentFile?.mkdirs()
            assets.open(assetPath).use { input -> target.outputStream().use { input.copyTo(it) } }
        } else {
            target.mkdirs()
            children.forEach { copyAssetDir("$assetPath/$it", File(target, it)) }
        }
    }

    private fun startWakeWord() {
        val m = model ?: return
        triggered = false
        try {
            // Grammar limits Vosk to "jarvis" or unknown noise, which is fast and cuts false triggers.
            val rec = Recognizer(m, 16000.0f, "[\"jarvis\", \"[unk]\"]")
            spkModel?.let { rec.setSpeakerModel(it) }
            wakeService = SpeechService(rec, 16000.0f).also {
                it.startListening(object : org.vosk.android.RecognitionListener {
                    override fun onPartialResult(hypothesis: String?) {
                        // With a voice profile (or while training) wait for the final result,
                        // because only that one says whose voice it was.
                        if (!needsSpeakerCheck() && hypothesis?.contains("jarvis") == true) onWakeWord()
                    }
                    override fun onResult(hypothesis: String?) {
                        handleWakeResult(hypothesis)
                    }
                    override fun onFinalResult(hypothesis: String?) {}
                    override fun onError(exception: Exception?) { Log.e(TAG, "Vosk error", exception) }
                    override fun onTimeout() {}
                })
            }
            if (pendingEnroll) {
                pendingEnroll = false
                startEnrollment()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Wake word failed", e)
            say("Wake word engine failed to start.")
            stopSelf()
        }
    }

    private fun stopWakeWord() {
        wakeService?.stop()
        wakeService?.shutdown()
        wakeService = null
    }

    private fun onWakeWord() {
        if (triggered) return
        triggered = true
        // Vosk and SpeechRecognizer can't share the mic, so release it first.
        main.post {
            stopWakeWord()
            if (ttsReady) {
                // Answer first, and start listening only once he has finished speaking.
                val result = tts?.speak("Yes, sir?", TextToSpeech.QUEUE_FLUSH, null, WAKE_REPLY)
                if (result == TextToSpeech.ERROR) listenForCommand()
            } else {
                ToneGenerator(AudioManager.STREAM_MUSIC, 80).startTone(ToneGenerator.TONE_PROP_BEEP, 150)
                listenForCommand()
            }
        }
    }

    // ---- voice -------------------------------------------------------------

    /** British, a little lower and slower: the calm butler sound. Uses whatever UK voices the phone has. */
    private fun setUpJarvisVoice() {
        val engine = tts ?: return
        engine.language = Locale.UK
        engine.setPitch(0.85f)
        engine.setSpeechRate(0.95f)

        // Google's UK voices gbb, gbd and rjs are male; fall back to any UK voice.
        val british = engine.voices.orEmpty().filter { it.locale == Locale.UK && !it.isNetworkConnectionRequired }
        val male = british.firstOrNull { v -> listOf("gbb", "gbd", "rjs").any { v.name.contains(it) } }
        (male ?: british.firstOrNull())?.let { engine.voice = it }

        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                if (utteranceId == WAKE_REPLY) main.post { listenForCommand() }
            }
            @Deprecated("Required by the abstract class")
            override fun onError(utteranceId: String?) {
                if (utteranceId == WAKE_REPLY) main.post { listenForCommand() }
            }
        })
    }

    // ---- voice lock: only wake up for the owner's voice --------------------

    private val voicePrefs get() = getSharedPreferences("jarvis_voice", Context.MODE_PRIVATE)

    /** Optional: copy the speaker model (assets/spk-model) the same way as the speech model. */
    private fun loadSpeakerModel() {
        try {
            if (assets.list("spk-model").isNullOrEmpty()) return
            val dir = File(filesDir, "spk-model")
            if (!File(dir, "final.ext.raw").exists()) copyAssetDir("spk-model", dir)
            spkModel = SpeakerModel(dir.absolutePath)
        } catch (e: Exception) {
            Log.e(TAG, "Speaker model failed, voice lock disabled", e)
            spkModel = null
        }
    }

    private fun profile(): DoubleArray? =
        voicePrefs.getString("profile", null)
            ?.split(",")?.mapNotNull { it.toDoubleOrNull() }?.toDoubleArray()
            ?.takeIf { it.isNotEmpty() }

    private fun threshold() = voicePrefs.getFloat("threshold", 0.6f)

    private fun needsSpeakerCheck() = spkModel != null && (enrolling || profile() != null)

    private fun handleWakeResult(hypothesis: String?) {
        if (hypothesis == null || !hypothesis.contains("jarvis")) return
        val spk = try {
            JSONObject(hypothesis).optJSONArray("spk")?.let { a -> DoubleArray(a.length()) { a.getDouble(it) } }
        } catch (e: Exception) {
            null
        }
        val owner = profile()
        when {
            enrolling -> if (spk != null) addEnrollSample(spk)
            spkModel == null || owner == null -> onWakeWord()
            spk == null || spk.size != owner.size -> Log.w(TAG, "No voice data, ignoring")
            else -> {
                val d = cosineDistance(spk, owner)
                Log.d(TAG, "Voice distance $d (limit ${threshold()})")
                if (d < threshold()) onWakeWord()
            }
        }
    }

    private fun cosineDistance(a: DoubleArray, b: DoubleArray): Double {
        var dot = 0.0
        var na = 0.0
        var nb = 0.0
        for (i in a.indices) {
            dot += a[i] * b[i]
            na += a[i] * a[i]
            nb += b[i] * b[i]
        }
        return 1.0 - dot / (sqrt(na) * sqrt(nb))
    }

    private fun startEnrollment() {
        if (spkModel == null) {
            say("I'm afraid the voice model is missing, sir.")
            return
        }
        enrollSamples.clear()
        enrolling = true
        say("Very well, sir. Please say my name five times, with a pause between each.")
    }

    private fun addEnrollSample(spk: DoubleArray) {
        enrollSamples += spk
        ToneGenerator(AudioManager.STREAM_MUSIC, 80).startTone(ToneGenerator.TONE_PROP_BEEP, 100)
        if (enrollSamples.size >= ENROLL_COUNT) finishEnrollment()
    }

    private fun finishEnrollment() {
        val n = enrollSamples.first().size
        val avg = DoubleArray(n)
        val usable = enrollSamples.filter { it.size == n }
        for (s in usable) {
            val norm = sqrt(s.sumOf { it * it })
            for (i in 0 until n) avg[i] += s[i] / norm
        }
        for (i in 0 until n) avg[i] /= usable.size
        voicePrefs.edit().putString("profile", avg.joinToString(",")).apply()
        enrolling = false
        enrollSamples.clear()
        say("Splendid, sir. I shall now answer only to your voice.")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_ENROLL) {
            if (wakeService != null) startEnrollment() else pendingEnroll = true
        }
        return START_STICKY
    }

    // ---- command capture -------------------------------------------------

    private fun listenForCommand() {
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle) {
                    val text = results
                        .getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull().orEmpty()
                    if (text.isNotBlank()) commands.handle(text) else say("I beg your pardon, sir?")
                    resumeWakeWord()
                }
                override fun onError(error: Int) {
                    Log.w(TAG, "Speech error $error")
                    resumeWakeWord()
                }
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                }
            )
        }
    }

    private fun resumeWakeWord() {
        main.postDelayed({
            recognizer?.destroy()
            recognizer = null
            startWakeWord()
        }, 800)
    }

    private fun say(text: String) {
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    // ---- foreground notification ----------------------------------------

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Jarvis listening", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("Jarvis is listening")
            .setContentText("Say \"Jarvis\"")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, notification)
        }
    }

    override fun onDestroy() {
        stopWakeWord()
        spkModel?.close()
        model?.close()
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "Jarvis"
        private const val CHANNEL = "jarvis_listening"
        private const val WAKE_REPLY = "wake_reply"
        private const val ENROLL_COUNT = 5
        const val ACTION_ENROLL = "com.example.jarvis.ENROLL"
    }
}
