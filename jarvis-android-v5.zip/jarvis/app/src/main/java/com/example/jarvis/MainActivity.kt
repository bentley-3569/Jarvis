package com.example.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.app.Activity
import androidx.core.content.ContextCompat

/** Minimal screen: grants permissions, then starts/stops the always-listening service. */
class MainActivity : Activity() {

    private val permissions = buildList {
        add(Manifest.permission.RECORD_AUDIO)
        add(Manifest.permission.READ_CONTACTS)
        add(Manifest.permission.CALL_PHONE)
        add(Manifest.permission.SEND_SMS)
        add(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }.toTypedArray()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val status = TextView(this).apply {
            text = "Say \"Jarvis\" once it's running.\nTry: \"call Mom\", \"set a timer for 5 minutes\", \"what's the weather\"."
            textSize = 16f
            gravity = Gravity.CENTER
        }
        val start = Button(this).apply {
            text = "Start Jarvis"
            setOnClickListener { startJarvis() }
        }
        val train = Button(this).apply {
            text = "Train my voice"
            setOnClickListener {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this@MainActivity, "Tap Start Jarvis first to grant permissions", Toast.LENGTH_LONG).show()
                } else {
                    ContextCompat.startForegroundService(
                        this@MainActivity,
                        Intent(this@MainActivity, JarvisService::class.java).setAction(JarvisService.ACTION_ENROLL)
                    )
                    Toast.makeText(this@MainActivity, "Say \"Jarvis\" five times after he asks", Toast.LENGTH_LONG).show()
                }
            }
        }
        val forget = Button(this).apply {
            text = "Forget my voice (answer to anyone)"
            setOnClickListener {
                getSharedPreferences("jarvis_voice", MODE_PRIVATE).edit().remove("profile").apply()
                Toast.makeText(this@MainActivity, "Voice profile cleared", Toast.LENGTH_SHORT).show()
            }
        }
        val menu = Button(this).apply {
            text = "Show commands menu"
            setOnClickListener { startActivity(Intent(this@MainActivity, MenuActivity::class.java)) }
        }
        val stop = Button(this).apply {
            text = "Stop Jarvis"
            setOnClickListener { stopService(Intent(this@MainActivity, JarvisService::class.java)) }
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
            addView(status)
            addView(start)
            addView(stop)
            addView(menu)
            addView(train)
            addView(forget)
        })
    }

    private fun startJarvis(askForPermissions: Boolean = true) {
        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        // Ask once; if something is denied, carry on (those features just won't work) instead of looping.
        if (askForPermissions && missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), 1)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            // Needed so the background service is allowed to open the contacts app / other apps.
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        ContextCompat.startForegroundService(this, Intent(this, JarvisService::class.java))
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        startJarvis(askForPermissions = false)
    }
}
