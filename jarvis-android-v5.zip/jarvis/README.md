# Jarvis (Android)

Always-on "Jarvis" wake word + voice commands (call contacts, open contacts, open apps).
No accounts or API keys needed.

## Setup

1. Download the small English speech model: https://alphacephei.com/vosk/models
   (`vosk-model-small-en-us-0.15`, about 40 MB). Unzip it.
2. Rename the unzipped folder to `model` and put it here:
   `app/src/main/assets/model`
   (so that `app/src/main/assets/model/am/final.mdl` exists).
3. Open this folder in Android Studio, let Gradle sync (it generates the wrapper), plug in your phone
   with USB debugging on, and press Run.
4. Tap **Start Jarvis**, grant the permissions (mic, contacts, phone, notifications, display over other apps).
5. Say "Jarvis", wait for the beep, then: "call Mom", "open contacts", "open Spotify", "what time is it".

## Commands (say "Jarvis" first, wait for the beep)

| Category | Examples |
|---|---|
| Calls and texts | "call Mom", "text Mom I'm on my way", "text Dad saying I'll be late" |
| Apps | "open contacts", "open Spotify" |
| Timers and alarms | "set a timer for 10 minutes", "set an alarm for 7:30 am", "wake me at 6" |
| Flashlight | "turn on the flashlight", "flashlight off" |
| Music | "pause", "play", "next song", "previous", "volume up", "volume down" |
| Info | "what's the battery", "what time is it", "what's the date", "weather", "weather in Denver" |
| Search and maps | "search for cheap flights", "navigate to Walmart" |
| Math | "what's 15% of 80", "12 times 7", "100 divided by 4" |
| Fun | "tell me a joke", "tell me a fun fact", "flip a coin", "roll a die", "pick a number between 1 and 10" |
| Settings screens | "Bluetooth settings", "Wi-Fi settings", "airplane mode", "brightness", "sound settings", "battery saver" (opens the screen; Android won't let apps flip the switch) |
| Media apps | "play despacito on YouTube", "play lofi on Spotify", "set volume to 50", "mute", "unmute" |
| Camera and home | "take a photo", "go home" |
| Speak out loud | "say hello, how are you" (put the call on speakerphone so the other person hears it) |
| Popup menu | "menu", "help", "what can you do" (also a button on the main screen) |
| Notes | "remind me to buy milk", "take a note ...", "read my notes", "clear my notes" |

Notes: texts send immediately with no confirmation. "Remind me to" only saves a note (it
does not alert you later). Weather uses degrees Fahrenheit and needs internet.

## Voice

Jarvis answers "Yes, sir?" and speaks with a British voice, a little lower and slower. It uses the
UK voices already on your phone. For the best sound, set your phone's text-to-speech engine to
**Google** and download the **English (UK)** voice data (Settings > General management > Text-to-speech
output). Samsung's default engine may sound less like a butler.

## Voice lock (only answer to you)

Tap **Train my voice** (or say "learn my voice"), then say "Jarvis" five times when he asks.
After that he only wakes for voices that match yours. This is approximate: a single word is a
short sample, so it can still let a similar voice through, or occasionally ignore you.
- Ignores you too often: say "be less strict" (or tap **Forget my voice** to turn the lock off).
- Lets others in: say "be stricter", or train again in a quiet room.
Needs the speaker model (`assets/spk-model`); the GitHub build file downloads it for you.
With the lock on, he reacts a little slower, because he has to hear the whole word first.

## How it works

- `JarvisService` - foreground service. Vosk listens offline for only the word "jarvis", beeps,
  releases the mic, runs Android's SpeechRecognizer for one command, then resumes listening.
- `CommandHandler` - parses the sentence and acts. Add new commands in `handle()`.
- `MainActivity` - permissions + start/stop buttons.

## Notes

- The first launch copies the model to internal storage, so the first start takes a few seconds.
- If "Jarvis" triggers too often or not enough, tune the grammar in `startWakeWord()`.
- Some phones (Samsung, Xiaomi, etc.) kill background apps: set Jarvis to "Unrestricted" battery use.
- The mic only works while the service notification is showing (Android requires it).
- Next step ideas: send unmatched commands to an LLM API, add texting, timers, music control.
